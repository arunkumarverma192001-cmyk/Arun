<?php
$servername = "sql309.infinityfree.com";   // ✅ MySQL Host Name
$username   = "if0_39755815";              // ✅ MySQL User Name
$password   = "ldVIRXD5ZnBLb";           // ✅ Aapka vPanel Password
$dbname     = "if0_39755815_aashubhai";    // ✅ MySQL Database Name

// Connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    // Optional: Test
    // echo "Database connected successfully!";
}
?>
